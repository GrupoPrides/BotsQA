class IncommingConfig {
	constructor(incommingChannelEnumId, config) {
		this.channelId = incommingChannelEnumId;
		this.config = config;
	}
}
module.exports = IncommingConfig;
