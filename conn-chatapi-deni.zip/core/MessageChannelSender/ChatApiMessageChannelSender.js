var urlLib = require("url");
var path = require("path");
var base64 = require("node-base64-image");
const BaseMessageChannelSender = require("./BaseMessageChannelSender");
class ChatApiMessageChannelSender extends BaseMessageChannelSender {
    constructor(baseUrl, token, device, idleTime) {
            super(token, device, idleTime);
            this.baseUrl = baseUrl;
        }
        //https://testwhatsapp.azurewebsites.net/messageIn
    sendMessage(phone, message, device) {
        var phone = phone.split("|")[2];
        var options = {
            method: "POST",
            url: `${this.baseUrl}message?token=${
				this.token
			}`,
            headers: {
                "content-type": "application/json"
            },
            body: {
                phone: phone,
                body: message
            },
            json: true
        };
        this._doRequest(options);
    }
    sendImage(phone, url, device) {
        var phone = phone.split("|")[2];
        var parsed = urlLib.parse(url);
        var fileName = path.posix.basename(parsed.pathname);

        var options = {
            method: "POST",
            url: `${this.baseUrl}/sendFile?token=${
				this.token
			}`,
            headers: {
                "content-type": "application/json"
            },
            body: {
                phone: phone,
                body: url,
                filename: fileName
            },
            json: true
        };
        this._doRequest(options);
    }
}
module.exports = ChatApiMessageChannelSender;