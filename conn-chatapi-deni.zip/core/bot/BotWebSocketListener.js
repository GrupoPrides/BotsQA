class BotWebSocketListener {
    constructor(streamUrl, outGoingService) {
        this.streamUrl = streamUrl;
        this.ws = null;
        this.outGoingService = outGoingService;
    }
    startReceiving() {
        console.log(
            "Starting W3C WebSocket Client for message streaming on conversationId: " +
            this.outGoingService.conversationId
        );
        var ws = new(require("websocket")).w3cwebsocket(this.streamUrl);
        ws.onerror = function() {
            console.log("Connection Error");
        };
        ws.onopen = function() {
            console.log("W3C WebSocket Client Connected");
        };
        ws.onclose = function() {
            console.log("W3C WebSocket Client Disconnected");
        };
        var outGoingService = this.outGoingService;
        ws.onmessage = function(e) {            
            if (typeof e.data === "string" && e.data.length > 0) {
                var data = JSON.parse(e.data);
                if((outGoingService.watermark == null)||
                   (data.watermark == null) ||
                   (outGoingService.watermark<data.watermark) 
                    ){
                    outGoingService.transFormActivities(data.activities, data.watermark);
                 } else {
                     console.log(e);
                    console.log("Ignored " + data.watermark)
                }
            }
        };
        this.ws = ws;
    }
}
module.exports = BotWebSocketListener;