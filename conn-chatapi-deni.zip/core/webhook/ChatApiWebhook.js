const BaseWebhook = require('./BaseWebhook');
class ChatApiWebhook extends BaseWebhook {
    constructor(botMessageListenerFactory, phone, baseUrl) {
        super(botMessageListenerFactory, phone, baseUrl);
    }
    listen(req, res) {
        //debugger;
        console.log(`${this.phone}:${this.baseUrl}:${req.originalUrl}`);        
        var data = req.body;
        if (data.messages != null) {
            for (var i = 0; i < data.messages.length; i++) { // For each message
                var msg = data.messages[i];               
                 if (msg.type == "gpNotification") {
                    this.handlerNotificationRequest(msg);
                } else {
                    if (msg.author == this.phone)
                        continue;
                    var text = msg.body;
                    var id = `${msg.chatId}|${msg.author}|${msg.author.replace('@c.us','')}|${this.phone}`;
                    var name = `${msg.senderName}`;
                    console.log(id + ":" + text);
                    if (msg.type == "image") {
                        this.handlerImageRequest(id, name, text);
                    } else {
                        this.handlerRequest(id, name, text);
                    }
                }
            }
        }
        res.send("ok");
    }
}
module.exports = ChatApiWebhook;