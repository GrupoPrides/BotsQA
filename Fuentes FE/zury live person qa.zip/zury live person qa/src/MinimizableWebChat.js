import classNames from 'classnames';
import React, { useCallback, useMemo, useState } from 'react';
import { createStore, createStyleSet } from 'botframework-webchat';

import WebChat from './WebChat';

import './fabric-icons-inline.css';
import './MinimizableWebChat.css';
import $ from "jquery"


const MinimizableWebChat = () => {
  const store = useMemo(
    () =>
      createStore({}, ({ dispatch }) => next => action => {
        if (action.type === 'DIRECT_LINE/CONNECT_FULFILLED') {
          console.log('DIRECT_LINE/CONNECT_FULFILLED');
        setTimeout(() => {
          dispatch({
            type: 'WEB_CHAT/SEND_EVENT',
            payload: {
              name: 'webchat/join',
              value: {
                language: window.navigator.language
              },
              
            }
          });
        }, 1000);

        displayAnimation();

        if (localStorage.getItem('welcome') === 'true'){
            console.log(window.navigator.language + ' WEB_CHAT/SEND_EVENT');
                  setTimeout(() => {
          dispatch({
            type: 'WEB_CHAT/SEND_EVENT',
            payload: {
              name: 'requestWelcomeDialog',
              value: {
                language: window.navigator.language
              }
            }
          });
        }, 1000);
        }
        } else if(action.type === 'DIRECT_LINE/CONNECT_FULFILLED' && localStorage.getItem("welcome") === "false"){
          dispatch({
            type: 'WEB_CHAT/SEND_EVENT',
            payload: {
              name: 'requestWelcomeDialog',
              value: {
                language: window.navigator.language
              }
            }
          });
        }else if (action.type === 'DIRECT_LINE/INCOMING_ACTIVITY') {
          if (action.payload.activity.from.role === 'bot') {
            setNewMessage(true);
          }
        }
        return next(action);
      }),
    []
  );

  const styleOptions = {
   /* bubbleBackground: '#222',
  bubbleBorder: 'solid 1px #444',
  bubbleBorderRadius: 20,
  bubbleFromUserBackground: '#222',
  bubbleFromUserBorder: 'solid 1px #444',
  bubbleFromUserBorderRadius: 20,
  bubbleFromUserTextColor: 'White',
  bubbleTextColor: 'White',
    botAvatarImage:
      './avatar.png',
    botAvatarInitials: 'BF',
    userAvatarImage: 'https://docs.microsoft.com/en-us/azure/bot-service/v4sdk/media/logo_bot.svg?view=azure-bot-service-4.0',
    userAvatarInitials: 'WC'*/
  };

  const styleSet = useMemo(
    () =>
      createStyleSet({
        backgroundColor: 'Transparent'
      }),
    []
  );

  const [loaded, setLoaded] = useState(false);
  const [minimized, setMinimized] = useState(true);
  const [newMessage, setNewMessage] = useState(false);
  const [side, setSide] = useState('right');
  const [token, setToken] = useState();

  // To learn about reconnecting to a conversation, see the following documentation:
  // https://docs.microsoft.com/en-us/azure/bot-service/rest-api/bot-framework-rest-direct-line-3-0-reconnect-to-conversation?view=azure-bot-service-4.0

  const handleFetchToken = useCallback(async () => {
    if (!token) {
      
      const res = await fetch('https://directline.botframework.com/v3/directline/conversations', { 
        method: 'POST',
        // headers: new Headers({
        //   'Authorization': 'Bearer ' + 'eMNfYn8I30s.BDY-noMP-22lUWnyUFhAU9ZWoHXjxgMsNUr5-VYpGq4', //produccion imas
        //   'Content-Type': '"Content-Type", "application/json"'
        // })
        headers: new Headers({
          'Authorization': 'Bearer ' + '6RUGzsqaYno.bNid_YdeXXgN5T3l0IcD1bcjHhDfDHzVWAH6FcSxysQ', //qa imas
          'Content-Type': '"Content-Type", "application/json"'
        })
      });
      const { token } = await res.json();

      
      console.log(res)
      localStorage.setItem("token",token);
      localStorage.setItem("welcome",false);
      setToken(token);
    }
  }, [setToken, token]);

  const handleMaximizeButtonClick = useCallback(async () => {
    setLoaded(true);
    setMinimized(false);
    setNewMessage(false);
  }, [setMinimized, setNewMessage]);

  const handleMinimizeButtonClick = useCallback(() => {
    setMinimized(true);
    setNewMessage(false);
  }, [setMinimized, setNewMessage]);

  const handleSwitchButtonClick = useCallback(() => {
    setSide(side === 'left' ? 'right' : 'left');
  }, [setSide, side]);
  const handleLanguageButtonClick = useCallback (()=>{
    setNewMessage(true)
  })

  // TODO: [P2] Currently, we cannot unmount Web Chat from DOM when it is minimized.
  //       Today, if we unmount it, Web Chat will call disconnect on DirectLineJS object.
  //       When minimized, we still want to maintain that connection while the UI is gone.
  //       This is related to https://github.com/microsoft/BotFramework-WebChat/issues/2750.

  return (
    <div className="minimizable-web-chat">
      {minimized && (
        <button className="maximize" onClick={handleMaximizeButtonClick}>
          {newMessage && <span className="ms-Icon ms-Icon--CircleShapeSolid red-dot" />}
        </button>
      )}
      {loaded && (
        <div className={classNames(side === 'left' ? 'chat-box left' : 'chat-box right', minimized ? 'hide' : '')}>
          <header>
            <div className="filler" />
            <button className="switch" onClick={handleSwitchButtonClick}>
              <span className="ms-Icon ms-Icon--Switch" />
            </button>
            <button className="minimize" onClick={handleMinimizeButtonClick}>
              <span className="ms-Icon ms-Icon--ChromeMinimize" />
            </button>
          </header>
          <WebChat
            className="react-web-chat"
            onFetchToken={handleFetchToken}
            store={store}
            styleSet={styleSet}
            token={token}
            styleOptions = {styleOptions}
          />
        </div>
      )}
    </div>
  );
};
 function displayAnimation(){


  console.log('displayAnimation');
  var imgName = Math.floor(Math.random()*4) + 1;
  var ROOT_FOLDER = 'https://gpbot.azureedge.net/ict/webchat/'
  // setTimeout(function(){
      $('.css-ljhy6a.css-7c9av6')
          .append($('<li id="animation-item" class="css-1qyo5rb">'
                      + '<div class="css-hgucfj css-1wi3416">'    //1
                          + '<div class="css-7xorrq avatar"></div>' 
                          + '<div class="content">' //2
                              + '<div class="row message">' //3
                                  + '<div class="css-ostbv8 bubble">' //4
                                      + '<div class="markdown css-o3xlyv"><p>' //5
                                      + '<img src="https://gpbot.azureedge.net/botimas/webchat/img/00-Ilustracion-Zury-IMAS.jpg" class="animation-image" />'
                                      //+ '<img src="' + ROOT_FOLDER + 'img/anim/' + imgName + '.png" class="animation-image" />'
                                      + '</p></div>' //5
                                  + '</div>' //4
                                  + '<div class="filler"></div>' 
                              + '</div>' //3
                              + '<div class="row">' 
                                  + '<span class="css-1phiexw">'
                                  // + 'Just now'
                                  + '</span>' 
                                  + '<div class="filler"></div>' 
                              + '</div>' 
                          + '</div>' //2
                          + '<div class="filler"></div>' 
                      + '</div>' //1
                  + '</li>').hide().fadeIn(2000));

      $('#animation-item').delay(10000).fadeOut(2000);
  // }, 1000);
}

function generateUserId(){
  return /*"dl_" +*/ Date.now().toString() + (Math.floor(Math.random() * 1000000) + 1).toString();
}
export default MinimizableWebChat;
