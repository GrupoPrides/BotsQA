import memoize from 'memoize-one';
import React from 'react';
import ReactWebChat, { createDirectLine, createStyleSet } from 'botframework-webchat';
import './WebChat.css';
import 'core-js/es6/map';
import 'core-js/es6/promise'
import 'core-js/es6/set';
import 'core-js/es6/symbol';
import 'core-js/fn/array/find-index';
import 'core-js/fn/array/includes';
import 'core-js/fn/math/sign';
import 'core-js/fn/object/assign';
import 'core-js/fn/string/starts-with';


export default class extends React.Component {
  constructor(props) {
    super(props);
//conversationId: localStorage.getItem('conversationId')
    this.createDirectLine = memoize(token => createDirectLine({ token }));

    this.state = {
      styleSet: createStyleSet({
        backgroundColor: 'Transparent',
        botAvatarImage: 'https://gpbot.azureedge.net/ict/webchat/img/Avatar-Sloth.jpg',
        botAvatarInitials: 'Smith',
        userAvatarImage: 'https://cdn3.iconfinder.com/data/icons/vector-icons-6/96/256-512.png',
        userAvatarInitials: 'User'    
      })
    };
  }

  componentDidMount() {
    console.log('componentDidMount' + this.props.token);
    !this.props.token && this.props.onFetchToken();
  }

  render() {
    const {
      props: { className, store, cardActionMiddleware, token, locale },
      state: { styleSet }
    } = this;

    return (
       token ?
        <ReactWebChat
          className={ `${ className || '' } web-chat` }
          directLine={ this.createDirectLine(token) }
          store={store }
          cardActionMiddleware = {cardActionMiddleware}
          styleSet={ styleSet }
          locale={locale}
        />
    :
        <div className={ `${ className || '' } connect-spinner` }>
          <div className="content">
            <div className="icon">
              <img src="https://gpbot.azureedge.net/ict/webchat/img/Avatar-Sloth.jpg" style={{borderRadius:'45px', width:'180px', height:'180px'}} alt="Mr. Sloth"></img>
            </div>
            <p style={{color:'black', fontSize:'25px'}}>Please wait while we are connecting.</p>
          </div>
        </div> 
     
    );
  }
}
