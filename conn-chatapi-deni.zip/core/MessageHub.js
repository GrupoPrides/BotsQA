var IncommingChannels = require("./config/IncommingChannels");
var WassengerWebhook = require("./webhook/WassengerWebhook");
var ChatApiWebhook = require("./webhook/ChatApiWebhook");
var BotMessageListener = require("./bot/BotMessageListener");
var WassengerMessageChannelSender = require("./messageChannelSender/WassengerMessageChannelSender");
var ChatApiMessageChannelSender = require("./messageChannelSender/ChatApiMessageChannelSender");

class MessageHub {
    constructor(messageHubConfig) {
        this.messageHubConfig = messageHubConfig;
    }

    _getFactory() {
        var factory = null;
        var channelConfig = this.messageHubConfig.incommingConfig;
        var directLineSecret = this.messageHubConfig.secret;

        switch (channelConfig.channelId) {
            case IncommingChannels.Wassenger:
                factory = (userid, userName, cb, resumeData) => {
                    var result = new BotMessageListener(
                        userid,
                        userName,
                        new WassengerMessageChannelSender(
                            channelConfig.token,
                            channelConfig.device,
                            channelConfig.idleTime
                        ),
                        resumeData
                    );
                    result.init(directLineSecret, (err) => {
                        cb(result, err);
                    });
                };
                break;
            case IncommingChannels.ChatApi:
                factory = (userid, userName, cb, resumeData) => {
                    var result = new BotMessageListener(
                        userid,
                        userName,
                        new ChatApiMessageChannelSender(
                            channelConfig.baseUrl,
                            channelConfig.token,
                            null,
                            channelConfig.idleTime
                        ), resumeData
                    );
                    result.init(directLineSecret, () => {
                        cb(result);
                    });
                };
                break;
            default:
                console.error(
                    `Not Factory found for ${this.messageHubConfig.Name} => ${
						channelConfig.channelId
					}`
                );
        }
        return factory;
    }
    _getWebHook(url) {
        var webhook = null;
        var channelConfig = this.messageHubConfig.incommingConfig;
        switch (channelConfig.channelId) {
            case IncommingChannels.Wassenger:
                webhook = new WassengerWebhook(this._getFactory(),url);
                break;
            case IncommingChannels.ChatApi:
                webhook = new ChatApiWebhook(this._getFactory(), channelConfig.phone,url);
                break;
            default:
                console.error(
                    `Not WebHook found for ${this.messageHubConfig.Name} => ${
						channelConfig.channelId
					}`
                );
        }
        return webhook;
    }
    register(server) {
        console.log(`staring ${this.messageHubConfig.name}`);
        var url = `/${this.messageHubConfig.name}/messageIn`;
        var webHook = this._getWebHook(url);
        server.post(url, (req, res) => {
            webHook.listen(req, res);
        });
        server.get(url, (req, res) => {
            res.send({ code: 200 });
        });
        console.log(`${this.messageHubConfig.name}: ${url}`);
        console.log(
            `${this.messageHubConfig.name}: And that's the way the cookie crumbles`
        );
    }
}
module.exports = MessageHub;