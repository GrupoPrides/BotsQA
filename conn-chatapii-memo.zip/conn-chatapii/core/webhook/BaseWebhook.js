class BaseWebhook {
    constructor(botMessageListenerFactory, phone, baseUrl) {
        this.botMessageListenerFactory = botMessageListenerFactory;
        this._goods = {};
        this._queue = {};
        this._state = {}; //Move to Cosmos
        this.phone = phone;
        this.baseUrl = baseUrl;
    }
    _handlerRequest(id, name, text, type) {
        var __this = this;
        if (this._goods[id] == null && this._goods[`${id}_|`] == null) {
            this._goods[`${id}_|`] = id;
            this._queue[id] = [];
            this._queue[id].push(function(cb) {
                if (__this._goods[id] == null) {
                    __this.botMessageListenerFactory(id, name, (instance, err) => {
                        if (err == null) {
                            __this._goods[id] = instance;
                            instance.on("close", resumeData => {
                                __this._queue[id] = null;
                                __this._goods[id] = null;
                                __this._goods[`${id}_|`] = null;
                                __this._state[`${id}_|`] = resumeData;
                                console.log(`${id}: that's all folks`);
                            });
                            cb();
                        } else {
                            __this._queue[id] = null;
                            __this._goods[id] = null;
                            __this._goods[`${id}_|`] = null;
                            __this._state[`${id}_|`] = null;
                            console.log(`${id}: that's all folks error on init`);
                        }
                    }, __this._state[`${id}_|`]);
                } else {
                    cb();
                }
            });
            var fn = () => {
                if (this._queue[id]) {
                    if (this._queue[id].length > 0) {
                        this._queue[id].shift()(() => {
                            setTimeout(() => {
                                fn();
                            }, 300);
                        });
                    } else {
                        setTimeout(() => {
                            fn();
                        }, 300);
                    }
                }
            };
            setTimeout(() => {
                fn();
            }, 300);
        }
        this._queue[id].push(function(cb) {
            switch (type) {
                case "image":
                    __this._goods[id].sendImageToBot(text);
                    break;
                case "gpNotification":
                    __this._goods[id].sendNotification(text);
                    break;
                default:
                    __this._goods[id].sendToBot(text);
                    break;
            }
            cb();
        });
    }
    handlerRequest(id, name, text) {
        this._handlerRequest(id, name, text);
    }
    handlerImageRequest(id, name, url) {
        this._handlerRequest(id, name, url, "image");
    }
    handlerNotificationRequest(notification) {
        this._handlerRequest(notification.address.user.id,
            notification.address.user.name,
            notification.message, "gpNotification")
    }
}
module.exports = BaseWebhook;