const IncommingChannels = require("./core/config/IncommingChannels");
var GPBotConnectorConfig = {
    channels: [
       
        {

            name: "BOT_MEMO",

            secret: "VwC40YyznPU.p3IkEEgQBn9vzgcbs-8yHM508qmZjFmdlpcz8VIEyAY",//memo

            incommingConfig: {

                channelId: IncommingChannels.ChatApi,

                token: "aosb4x6waq0dnnza", //memo1

                baseUrl: "https://eu231.chat-api.com/instance223734/",//memo1
                
                phone: "50766782032@c.us",//memo1

                idleTime: 360 //Seconds

            }

          },
          {

            name: "BOT_MEMO2",
            secret: "VwC40YyznPU.p3IkEEgQBn9vzgcbs-8yHM508qmZjFmdlpcz8VIEyAY",//memo

            incommingConfig: {

                channelId: IncommingChannels.ChatApi,

                token: "jmakqruxhgajkn4l", //memo2

                baseUrl: "https://eu231.chat-api.com/instance223737/",//memo2

                phone: "50766778252@c.us",//memo2

                idleTime: 360 //Seconds

            }

          }
        
    ]
};
module.exports = GPBotConnectorConfig;