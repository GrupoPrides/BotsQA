class MessageHubConfig {
	constructor(secret, name, incommingConfig) {
		this.secret = secret;
		this.name = name;
		this.incommingConfig = incommingConfig;
	}
}
module.exports = MessageHubConfig;
