var Swagger = require("swagger-client");
var ActivityFactory = require("../utils/ActivityFactory");
var rp = require("request-promise");
var directLineSpec = require("../../assets/directline-swagger.json");
var BotWebSocketListener = require("./BotWebSocketListener");
const EventEmitter = require("events");
class BotMessageListener extends EventEmitter {
    constructor(userId, userName, messageChannelSender, resumeData) {
        super();
        this.directLine = null;
        this.conversationId = null;
        this.watermark = null;
        this.token = null;
        this.af = new ActivityFactory();
        if (resumeData != null) {
            this.conversationId = resumeData.conversationId;
            this.watermark = resumeData.watermark;
            // this.token = resumeData.token;
            this.token = resumeData.secret;
            this.expireIn = resumeData.expireIn;
            this.secret = resumeData.secret;
            console.log("====" + JSON.stringify(resumeData));
        }
        this.from = this.af.factoringFrom(userId, userName);
        this.messageChannelSender = messageChannelSender;
        this.BotListener = null;

        this.messageChannelSender.on("close", () => {
            this._close();
        });
    }
    _close() {
            if (this.BotListener != null) {
                if (this.BotListener.ws != null) this.BotListener.ws.close();
            }
            if (this.directLine.AutoRefreschTimer != null) {
                clearInterval(this.directLine.AutoRefreschTimer);
            }
            this.emit("close", {
                conversationId: this.conversationId,
                watermark: this.watermark,
                token: this.token,
                expireIn: this.expireIn,
                secret: this.secret
            });
        }
        // Send message to the bot sms
    sendToBot(input) {
        // Send message
        this.directLine.Conversations.Conversations_PostActivity({
            conversationId: this.conversationId,
            activity: this.af.factoringActivity(input, this.from)
        }).catch(function(err) {
            console.error("Error sending message:", err);
        });
    }

    // Send message to the bot image
    sendImageToBot(url) {
        // Send message
        this.directLine.Conversations.Conversations_PostActivity({
            conversationId: this.conversationId,
            activity: this.af.factoringImageActivity(url, this.from)
        }).catch(function(err) {
            console.error("Error sending message:", err);
        });
    }
    sendNotification(notification) {
            // Send message
            this.directLine.Conversations.Conversations_PostActivity({
                conversationId: this.conversationId,
                activity: this.af.factoringEvent(notification, this.from, "gpNotification")
            }).catch(function(err) {
                console.error("Error sending message:", err);
            });
        }
        // Helpers methods
    transFormActivities(activities, watermark) {
        if (activities && activities.length) {
            // Ignore own messages
            activities = activities.filter(m => {
                return m.from.id !== this.from.id;
            });
            console.log("=====" + watermark);
            this.watermark = watermark;
            if (activities.length) {
                // Print other messages
                activities.forEach(activity => this._transFormActivity(activity));
            }
        }
    }
    _transFormActivity(activity) {
        var messageToSend = this.af.transFormActivity(activity);
        if (messageToSend.length > 0) {
            var __this = this;
            messageToSend.forEach(msg => {
                if (msg != null) {
                    if (msg.images != null)
                        msg.images.forEach(url => {
                            __this.messageChannelSender.sendImage(__this.from.id, url);
                        });
                    if (msg.text) {
                        console.log(__this.from.id + ":" + msg.text);
                        __this.messageChannelSender.sendMessage(__this.from.id, msg.text);
                    }
                }
            });
        }
    }


    init(lineSecret, cb) {
        const _Me = this;
        var dlClient = new Swagger({
                spec: directLineSpec,
                usePromise: true
            })
            .then(function(internalDLClient) {
                // Obtain a token using the Direct Line secret
                return rp({
                    url: "https://directline.botframework.com/v3/directline/tokens/generate",
                    method: "POST",
                    headers: { Authorization: `Bearer ${lineSecret}` },
                    json: true
                }).then(function(response) {
                    // Then, replace the client's auth secret with the new token
                    var token = _Me.token;
                    if (_Me.token == null) {
                        _Me.token = response.token;
                        _Me.expireIn = response.expires_in;
                        _Me.secret = lineSecret;
                    }
                    //token = _Me.token;
                    token = _Me.secret;
                    internalDLClient.clientAuthorizations.add(
                        "AuthorizationBotConnector",
                        new Swagger.ApiKeyAuthorization(
                            "Authorization",
                            "Bearer " + token,
                            "header"
                        )
                    );
                    internalDLClient.expires_in = response.expires_in;

                    internalDLClient.AutoRefresh = function() {
                        var __this = this;
                        this.Tokens.Tokens_RefreshToken()
                            .then(responseTK => {
                                try {
                                    const dataR = JSON.parse(responseTK.data);
                                    const newToken = dataR.token;
                                    _Me.token = newToken;
                                    _Me.expireIn = dataR.expires_in
                                    __this.clientAuthorizations.authz.AuthorizationBotConnector.value =
                                        "Bearer " + newToken;
                                } catch (err) {
                                    console.error("Tokens_RefreshToken:", err);
                                }
                            })
                            .catch(function(err) {
                                console.error("Tokens_RefreshToken:", err);
                            });
                    };

                    var interval = (internalDLClient.expires_in - 300) * 1000;
                    var fiveMinutes = 5 * 60 * 100;
                    /*
                    internalDLClient.AutoRefreschTimer = setInterval(
                        () => {
                            internalDLClient.AutoRefresh();
                        },
                        interval < fiveMinutes ? fiveMinutes : interval
                    );*/
                    return internalDLClient;
                });
            })
            .catch(function(err) {
                console.error("Error initializing DirectLine client", err);
            });
        var __this = this;
        // Once the client is ready, create a new conversation
        dlClient
            .then(function(internalDLClient) {
                __this.directLine = internalDLClient;
                var fn = function(response) {
                    var responseObj = response.obj;
                    internalDLClient.conversationId = responseObj.conversationId;
                    __this.conversationId = responseObj.conversationId;
                    // Start receiving messages from WS stream - using W3C client
                    __this.BotListener = new BotWebSocketListener(
                        responseObj.streamUrl,
                        __this
                    );
                    __this.BotListener.startReceiving();
                    cb();
                }
                var fnError = function(err) {
                    console.error("Error initializing DirectLine client", err);
                    cb(err);
                }
                if (__this.conversationId == null) {
                    console.log("Conversations_StartConversation" + __this.token);
                    internalDLClient.Conversations.Conversations_StartConversation().then(fn).catch(fnError);
                } else {
                    console.log("Conversations_ReconnectToConversation   " + __this.token);
                    internalDLClient.Conversations.Conversations_ReconnectToConversation({
                        conversationId: __this.conversationId,
                        watermark: __this.watermark
                    }).then(fn).catch(fnError);;
                }
            })
            .catch(function(err) {
                console.error("Error initializing DirectLine client", err);
            });
    }
}
module.exports = BotMessageListener;