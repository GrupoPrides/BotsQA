var IncommingChannels = Object.freeze({ Wassenger: 1, ChatApi: 2 });
module.exports = IncommingChannels;
