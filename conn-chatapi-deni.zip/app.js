const express = require("express");
const bodyParser = require("body-parser");
const GPBotConnectorConfig = require("./config");
const MessageHub = require("./core/MessageHub");
require('console-stamp')(console, { pattern: 'dd/mm/yyyy HH:MM:ss.l' });

console.log("Lets try on");
var server = express();

server.use(bodyParser.json());
server.use(bodyParser.urlencoded({ extended: true }));
GPBotConnectorConfig.channels.forEach(config => {
    var connector = new MessageHub(config);
    connector.register(server);
});
var port = process.env.port || process.env.PORT || 3000;
var listener = server.listen(port);
server.get("/", function(req, res) {
    res.send('Conector de GPBOTGP_PRODUCCION ');
});
console.log("Lets get ready to rumble");