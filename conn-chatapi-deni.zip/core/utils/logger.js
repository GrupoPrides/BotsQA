class Logger {
    log() {
        if (arguments.length) {
            var timestamp = new Date().toJSON(); // The easiest way I found to get milliseconds in the timestamp
            var args = arguments;
            args[0] = timestamp + ' > ' + arguments[0];
            this.logCopy.apply(this, args);
        }
    }
}