class ActivityFactory {
	factoringFrom(userId, name) {
		return {
			id: userId,
			name: name
		};
	}
	factoringActivity(input, from) {
		return {
			textFormat: "plain",
			text: input,
			type: "message",
			from: from
		};
	}
    factoringImageActivity(url, from) {
        return {
            textFormat: "plain",
            attachments: [{
                //contentType:
                contentUrl: url
            }],
            type: "message",
            from: from
        };
    }
    factoringEvent(input, from, eventName) {
		const r = {
            name: eventName,
            type: "event",
            from: from,
            value: input
        };
		console.log(JSON.stringify(r));
        return r;
    }
	transFormActivity(activity) {
		var messageToSend = [];
		if (activity.text) {
			var text = activity.text;
			if (activity.suggestedActions) {
				activity.suggestedActions.forEach(attachment => {
					if (attachment.actions != null)
						for (var i = 0; i < attachment.actions.length; i++) {
							var lb = i > 0 ? "\n" : "";
							var label = "";
							var button = attachment.actions[i];
							label = `${button.value}`;
							text = `${text}${lb}${label}`;
						}
				});
			}
			messageToSend.push({ text: text });
		}
		if (activity.attachments) {
			activity.attachments.forEach(attachment => {
				switch (attachment.contentType) {
					case "application/vnd.microsoft.card.hero":
						messageToSend.push(
							this._renderHeroCard(attachment, activity.attachmentLayout)
						);
						break;
					case "image/png":
						var images = [];
						images.push(attachment.contentUrl);
						messageToSend.push({ images: images });
						break;
				}
			});
		}
		return messageToSend;
	}
	_renderHeroCard(attachment, attachmentLayout) {
		var result = "";
		var images = [];
		if (attachment.content != null) {
			result = attachment.content.text || "";
			if (attachment.content.buttons != null) {
				result = result == "" ? "" : result + "\n";
				for (var i = 0; i < attachment.content.buttons.length; i++) {
					var lb = i > 0 ? "\n" : "";
					var label = "";
					var bullet = attachmentLayout == "carousel" ? "" : `${i + 1})`;
					var button = attachment.content.buttons[i];
					if (button.type == "openUrl")
						label = `${button.title} ${button.value}`;
					else label = `${bullet}${button.value}`;
					result = `${result}${lb}${label}`;
				}
			}
			if (attachment.content.images != null) {
				for (var i = 0; i < attachment.content.images.length; i++) {
					images.push(attachment.content.images[i].url);
				}
			}
		}
		return { images: images, text: result == "" ? null : result };
	}
}
module.exports = ActivityFactory;
