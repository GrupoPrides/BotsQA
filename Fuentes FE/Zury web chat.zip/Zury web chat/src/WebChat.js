import React, { useEffect, useMemo } from 'react';
import ReactWebChat, { createDirectLine, createStyleSet } from 'botframework-webchat';

import './WebChat.css';

const WebChat = ({ className, onFetchToken, store, token }) => {
  const directLine = useMemo(() => createDirectLine({ token }), [token]);

  const styleSet = useMemo(
    () =>
      createStyleSet({
        backgroundColor: 'Transparent',
        //bubbleBackground: '#222',
        //bubbleBorder: 'solid 1px #444',
        //bubbleBorderRadius: 20,
        //bubbleFromUserBackground: '#0ABADE',
        //bubbleFromUserBorder: 'solid 1px #444',
        //bubbleFromUserBorderRadius: 20,
        //bubbleFromUserTextColor: 'White',
        //bubbleTextColor: 'White',      
        botAvatarImage: 'https://gpbot.azureedge.net/botimas/webchat/img/avatar.png',
        botAvatarInitials: 'Zuri',
        userAvatarImage: 'https://cdn3.iconfinder.com/data/icons/vector-icons-6/96/256-512.png',
        userAvatarInitials: 'User'
      }),
    []
  );

  useEffect(() => {
    onFetchToken();
  }, [onFetchToken]);

  return token ? (

    // <>
    //   <div class="content">
    //     <div class="row message">
    //       <div class="css-ostbv8 bubble">
    //         <div class="markdown css-o3xlyv">
    //           <p>
    //             {/* <img src="https://gpbot.azureedge.net/botimas/webchat/img/00-Ilustracion-Zury-IMAS.jpg" className="animation-image"/> */}
    //             <span className="avat2" />
    //           </p>
    //         </div>
    //         <div class="filler"></div>
    //       </div>
    //       <div class="row">
    //         <span class="css-1phiexw"></span>
    //         <div class="filler"></div>
    //       </div>
    //     </div>
    //   </div>
      <ReactWebChat 
      className={`${className || ''} web-chat`} 
      directLine={directLine} 
      store={store} 
      styleSet={styleSet} 
      />
    //</>
  ) : (
    <div className={`${className || ''} connect-spinner`}>
      <div className="content">
        <div className="icon">
          {/* <span className="ms-Icon ms-Icon--Robot" /> */}
          <span className="avat" />
        </div>
        <p style={{color:'black', fontSize:'25px'}}>Por favor espere mientras nos conectamos.</p>
        {/* <p>Please wait while we are connecting.</p> */}
      </div>
    </div>
  );
};

export default WebChat;
