const IncommingChannels = require("./core/config/IncommingChannels");
var GPBotConnectorConfig = {
    channels: [
       
        {

            name: "BOT_DENI",

            secret:"N2mbU_KIX-Y.fCDLKQLWVuwk_9iRMn4tpoCyRnUVHhVhl6uQrHPyutE",

            incommingConfig: {

                channelId: IncommingChannels.ChatApi,

                token: "gud21ir63m1anwrj",

                baseUrl: "https://eu43.chat-api.com/instance48959/",

                phone: "50622862825@c.us",

                idleTime: 360 //Seconds

            }

          }
        
    ]
};
module.exports = GPBotConnectorConfig;