$(document).ready(function () {
    var observer = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutationRecord) {
             var displayMemoMin = $('#DivMinimizableWebChatBtn')[0].style.display;
             var displayNeotel = $('#cntNeoWebChat')[0].style.display;
            //var displayMemoMin = document.getElementById('DivMinimizableWebChatBtn').style.display;
            //var displayNeotel = document.getElementById('cntNeoWebChat').style.display;
            if (displayMemoMin == 'none' && displayNeotel == 'none') {
                 $('#DivMinimizableWebChatBtn').css("display", "block");
                //document.getElementById('DivMinimizableWebChatBtn').style.display = "block";
            }
        });
    });
var target = document.getElementById('cntNeoWebChat');
observer.observe(target, { attributes: true, attributeFilter: ['style'] });

});
function AvatarMemoClick() {
    // document.getElementById('cntNeoChat').draggable();
    //startNeoWebChat();
    $('#cntNeoChat').draggable(); startNeoWebChat();

    //document.getElementById('DivMinimizableWebChatBtn').style.display = "none";
    $('#DivMinimizableWebChatBtn').css("display", "none");
}