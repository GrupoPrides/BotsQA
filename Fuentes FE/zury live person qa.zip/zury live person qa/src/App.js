import React from 'react';

import MinimizableWebChat from './MinimizableWebChat';
import WebPageBackground from './bg.PNG';
import './App.css';



const App = () => (
  <div className="App">
    <img alt="product background" src={WebPageBackground}/>
    {/* { <MinimizableWebChat /> } */}
  </div>
);

export default App;
