const EventEmitter = require("events");

class BaseMessageChannelSender extends EventEmitter {
	constructor(token, device, idleTime) {
		super();
		this.token = token;
		this.defaultDevice = device;
		this._queue = [];
		this._emptyRuns = 0;
		this.idleTime = (idleTime * 1000) / 300;
		var fn = () => {
			try {
				if (this._queue != null && this._emptyRuns <= this.idleTime) {
					if (this._queue.length > 0) {
						this._emptyRuns = 0;
						this._queue.shift()(() => {
							this._queueTimer = setTimeout(() => {
								fn();
							}, 300);
						});
					} else {
						this._emptyRuns = this._emptyRuns + 1;
						this._queueTimer = setTimeout(() => {
							fn();
						}, 300);
					}
				} else {
					clearTimeout(this._queueTimer);
					this.emit("close");
				}
			} catch (ex) {
				console.error("BaseMessageChannelSender", ex);
				this.emit("close");
			}
		};
		this._queueTimer = setTimeout(() => {
			fn();
		}, 300);
	}

	sendMessage(phone, message, device) {}
	sendImage(phone, url, device) {}
	close() {
		this._queue = null;
		clearTimeout(this._queueTimer);
		this.emit("close");
	}

	_defaultCB(error, response, body) {
		if (error) log(error);
	}
	_doRequest(options) {
		this._queue.push(cb => {
			var request = require("request");
			request(options, (error, response, body) => {
				this._defaultCB(error, response, body);
				cb();
			});
		});
	}
}
module.exports = BaseMessageChannelSender;
