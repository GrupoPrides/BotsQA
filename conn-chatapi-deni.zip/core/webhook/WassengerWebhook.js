const BaseWebhook = require('./BaseWebhook');
class WassengerWebhook extends BaseWebhook {
    constructor(botMessageListenerFactory, url) {
            super(botMessageListenerFactory, null, url);
        }
        //https://docs.wassenger.com/#operation/createMessage
    listen(req, res) {
        var wassengerMjs = req.body;
        if (wassengerMjs.event == "message:in:new") {
            var id = `${wassengerMjs.data.to}|${wassengerMjs.data.from}|${wassengerMjs.data.fromNumber}`;
            var name = `${wassengerMjs.data.chat.contact.displayName}`;
            this.handlerRequest(id, name, wassengerMjs.data.body);
        }
        res.send({ code: 200 });
    }
}
module.exports = WassengerWebhook;