const BaseMessageChannelSender = require("./BaseMessageChannelSender");
class WassengerMessageChannelSender extends BaseMessageChannelSender {
	constructor(token, device, idleTime) {
		super(token, device, idleTime);
	}

	sendMessage(phone, message, cb, device) {
		var phone = phone.split("|")[2];
		var options = {
			method: "POST",
			url: "https://api.wassenger.com/v1/messages",
			headers: {
				token: this.token,
				"content-type": "application/json"
			},
			body: {
				phone: phone,
				message: message,
				device: device || this.defaultDevice
			},
			json: true
		};
		this._doRequest(options);
	}
}
module.exports = WassengerMessageChannelSender;
